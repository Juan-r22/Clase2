<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);
    $edad = $_POST['edad'];
    $genero = $_POST['genero'];

    $sql = "INSERT INTO usuarios (nombre, correo, contraseña, edad, genero)
            VALUES ('$nombre', '$correo', '$contraseña', $edad, '$genero')";

    if (mysqli_query($conn, $sql)) {
        header("Location: login.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<link rel="stylesheet" href="estilo.css">
<div class="container">
  <h2>Registro SmithStrong</h2>
  <form method="POST">
    <input name="nombre" placeholder="Nombre completo" required>
    <input name="correo" type="email" placeholder="Correo electrónico" required>
    <input name="contraseña" type="password" placeholder="Contraseña" required>
    <input name="edad" type="number" placeholder="Edad" required>
    <select name="genero">
      <option value="Masculino">Masculino</option>
      <option value="Femenino">Femenino</option>
    </select>
    <button type="submit">Registrarse</button>
    <a href="login.php">¿Ya tienes cuenta? Inicia sesión</a>
  </form>
</div>