<?php
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    $sql = "SELECT * FROM usuarios WHERE correo='$correo'";
    $resultado = mysqli_query($conn, $sql);
    $usuario = mysqli_fetch_assoc($resultado);

    if ($usuario && password_verify($contraseña, $usuario['contraseña'])) {
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['nombre'] = $usuario['nombre'];
        header("Location: dashboard.php");
    } else {
        echo "Credenciales incorrectas";
    }
}
?>

<link rel="stylesheet" href="estilo.css">
<div class="container">
  <h2>Login SmithStrong</h2>
  <form method="POST">
    <input name="correo" type="email" placeholder="Correo" required>
    <input name="contraseña" type="password" placeholder="Contraseña" required>
    <button type="submit">Ingresar</button>
    <a href="registro.php">¿No tienes cuenta? Regístrate</a>
  </form>
</div>