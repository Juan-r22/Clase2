<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$sql = "SELECT * FROM imc_historial WHERE usuario_id = $usuario_id ORDER BY fecha DESC";
$resultado = mysqli_query($conn, $sql);
?>

<link rel="stylesheet" href="estilo.css">
<div class="container">
  <h2>Historial de IMC</h2>
  <?php while ($row = mysqli_fetch_assoc($resultado)): ?>
    <p>📅 <?= $row['fecha'] ?> — IMC: <?= round($row['imc'], 2) ?> (Peso: <?= $row['peso'] ?>kg, Altura: <?= $row['altura'] ?>m)</p>
  <?php endwhile; ?>
  <a href="dashboard.php">Volver</a>
</div>