<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$nombre = $_SESSION['nombre'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $peso = $_POST['peso'];
    $altura = $_POST['altura'];
    $imc = $peso / ($altura * $altura);
    $usuario_id = $_SESSION['usuario_id'];

    $sql = "INSERT INTO imc_historial (usuario_id, peso, altura, imc)
            VALUES ($usuario_id, $peso, $altura, $imc)";
    mysqli_query($conn, $sql);

    $resultado = round($imc, 2);
    $mensaje = "";

    if ($imc < 18.5) {
        $mensaje = "💡 Dieta: Alta en calorías y proteínas<br>🏋️ Rutina: Fuerza moderada";
    } elseif ($imc < 25) {
        $mensaje = "💡 Dieta: Equilibrada<br>🏃 Rutina: Cardio + fuerza";
    } else {
        $mensaje = "💡 Dieta: Baja en grasas<br>🚶 Rutina: Cardio diario + fuerza ligera";
    }
}
?>

<link rel="stylesheet" href="estilo.css">
<div class="container">
  <h2>Bienvenido, <?= $nombre ?> 💪</h2>
  <form method="POST">
    <input name="peso" type="number" step="0.01" placeholder="Peso (kg)" required>
    <input name="altura" type="number" step="0.01" placeholder="Altura (m)" required>
    <button type="submit">Calcular IMC</button>
  </form>

  <?php if (isset($resultado)): ?>
    <h3>Tu IMC es: <?= $resultado ?></h3>
    <p><?= $mensaje ?></p>
    <a href="historial.php">Ver historial de IMC</a>
    <a href="logout.php">Cerrar sesión</a>
  <?php endif; ?>
</div>